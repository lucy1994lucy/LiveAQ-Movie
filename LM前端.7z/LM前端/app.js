//app.js


var config = require('comm/script/config')



App({
  onShow: function () {
    console.log('App Show')
  },
  onHide: function () {
    console.log('App Hide')
  },
  onLaunch: function () {


    console.log('App Launch')
    //调用API从本地缓存中获取数据
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)






    this.getUserInfo()
    //初始化缓存
    this.initStorage()

    try {
      wx.clearStorageSync()
    } catch (e) { }





    //调用API从本地缓存中获取token数据
    var token = wx.getStorageSync('token') || "";
    console.info("从本地缓存中获取token数据");

    if (token == null || token == "") {
      var that = this;
      console.info("token is null");
      this.login();
      //token不为空，则根据token查询用户信息保存到全局数据里面
    } else {
      console.info("token is not null");
      this.queryUserInfo(token);
    }
  },

  globalData: {
    userInfo: null
  },
  //获取用户信息
  getUserInfo: function (cb) {


    var that = this
    if (this.globalData.userInfo) {
      typeof cb == "function" && cb(this.globalData.userInfo)
    } else {
      //调用登录接口
      wx.login({
        success: function () {
          wx.getUserInfo({
            success: function (res) {
              that.globalData.userInfo = res.userInfo
              typeof cb == "function" && cb(that.globalData.userInfo)
            }
          })
        }
      })
    }

    //如果全局用户信息存在，则直接设置数据
    if (this.globalData.userInfo) {
      console.info("全局用户信息存在，则直接设置数据")
      typeof cb == "function" && cb(this.globalData.userInfo)

      //不存在则调用登录接口
    } else {
      console.info("本地全局用户数据不存在，调用登录接口")
      this.login(cb);
    }
  },


  getCity: function (cb) {
    var that = this
    wx.getLocation({
      type: 'gcj02',
      success: function (res) {
        var locationParam = res.latitude + ',' + res.longitude + '1'
        wx.request({
          url: config.apiList.baiduMap,
          data: {
            ak: config.baiduAK,
            location: locationParam,
            output: 'json',
            pois: '1'
          },
          method: 'GET',
          success: function (res) {
            config.city = res.data.result.addressComponent.city.slice(0, -1)
            typeof cb == "function" && cb(res.data.result.addressComponent.city.slice(0, -1))
          },
          fail: function (res) {
            // 重新定位
            that.getCity();
          }
        })
      }
    })
  },



  initStorage: function () {
    wx.getStorageInfo({
      success: function (res) {
        // 判断电影收藏是否存在，没有则创建
        if (!('film_favorite' in res.keys)) {
          wx.setStorage({
            key: 'film_favorite',
            data: []
          })
        }
        // 判断人物收藏是否存在，没有则创建
        if (!('person_favorite' in res.keys)) {
          wx.setStorage({
            key: 'person_favorite',
            data: []
          })
        }
        // 判断电影浏览记录是否存在，没有则创建
        if (!('film_history' in res.keys)) {
          wx.setStorage({
            key: 'film_history',
            data: []
          })
        }
        // 判断人物浏览记录是否存在，没有则创建
        if (!('person_history' in res.keys)) {
          wx.setStorage({
            key: 'person_history',
            data: []
          })
        }
        // 个人信息默认数据
        var personInfo = {
          name: '',
          nickName: '',
          gender: '',
          age: '',
          birthday: '',
          constellation: '',
          company: '',
          school: '',
          tel: '',
          email: '',
          intro: ''
        }
        // 判断个人信息是否存在，没有则创建
        if (!('person_info' in res.keys)) {
          wx.setStorage({
            key: 'person_info',
            data: personInfo
          })
        }
        // 判断相册数据是否存在，没有则创建
        if (!('gallery' in res.keys)) {
          wx.setStorage({
            key: 'gallery',
            data: []
          })
        }
        // 判断背景卡选择数据是否存在，没有则创建
        if (!('skin' in res.keys)) {
          wx.setStorage({
            key: 'skin',
            data: ''
          })
        }
      }
    })
  },


  //登录接口,登录成功后设置，全局用户信息
  login: function (cb) {
    var that = this;

    wx.login({
      //获取授权码code
      success: function (e) {
        console.info("授权码code")
        console.info(e.code)
        //获取用户信息接口 
        wx.getUserInfo({
          success: function (res) {
            that.globalData.userInfo = res.userInfo;
            console.info(res.userInfo)
            //调用后端登录接口 
            wx.request({
              url: that.globalData.backend_url + '/user/login',
              data: {
                code: e.code,
                nickname: res.userInfo.nickName,
                head_img: res.userInfo.avatarUrl

              },
              //登录成功，则保存token到本地
              success: function (res) {

                if (res.data.errno == 0) {
                  console.info("登录成功，则保存token到本地 ")
                  wx.setStorageSync('token', res.data.data)
                  that.queryUserInfo(res.data.data);

                }
              }
            })

            typeof cb == "function" && cb(that.globalData.userInfo)
          }
        })
      }
    })
  },


  //根据token获取用户信息，token即是登录凭证
  queryUserInfo: function (token) {
    var that = this;

    if (token != "" && token != null) {

      wx.request({
        url: that.globalData.backend_url + '/user/query',
        data: { token: token },
        method: 'POST',
        //登录成功，则保存token到本地
        success: function (res) {

          console.info(res.data.errno)
          if (res.data.errno == 0) {
            console.info("数据库获取用户信息成功，保存到全局数据 ")
            var result = res.data.data;
            var user = {};
            user.nickName = result.nickname;
            user.avatarUrl = result.head_img;
            user.age = result.age;
            user.phone = result.phone;
            //设置全局用户数据
            that.globalData.userInfo = user;
          }
        }
      })
    }
  },


  //全局数据
  globalData: {
    userInfo: null,
    backend_url: "http://120.25.1.38:8360"
  }
}); 