var app = getApp()
Page({
  data: {

  },
  onLoad: function (options) {
    var that = this
    console.log('onLoad')
    wx.request({
      url: app.globalData.backend_url + '/question/findmyquestion?nickName=' + app.globalData.userInfo.nickName,
      header: {
        'Content-Type': 'application/json'
      },
      success: function (res) {
        that.setData({
          list: res.data.data
        })

      }
    })
  }

})