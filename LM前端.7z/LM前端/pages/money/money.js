const AV = require('../../libs/av-weapp.js');
Page({
  data:{
    
  },
  onLoad:function(options){
  
  },
  getPay:function(){
    console.log("获取用户OpenId");
    var user = AV.User.current();
    var that = this;
    console.log(user.id);
    var param = {
      "id" : user.id
    }
    AV.Cloud.run("getUser",param).then(function(res){
      that.setData({
        openid:res[0].authData.lc_weapp.openid
      })
    })
    var payParam = {
      "openid" : that.data.openid
    }
    AV.Cloud.run("getPay",payParam).then(function(res){
      console.log(res);
      wx.requestPayment({
        timeStamp: res.timeStamp,
        nonceStr: '20150331' + Math.random().toString().substr(2, 10),
        package: res.package,
        signType: 'MD5',
        paySign: res.paySign,
        success: function(res){
          // success
        },
        fail: function() {
          // fail
        },
        complete: function() {
          // complete
        }
      })
    })
  }
})