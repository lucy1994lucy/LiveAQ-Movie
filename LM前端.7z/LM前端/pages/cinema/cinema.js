Page({
  data: {
    infos1: [],
    infos2: [],
    infos3: [],
    infos4: [],
    infos5: [],
    infos6: [],
    cinema: [],
   
  },
  onLoad: function (options) {
    var that = this;
    wx.request({
      url: 'http://m.maoyan.com/cinemas.json',
      data: {},
      method: 'GET',
      success: function (res) {
        console.log(res)
        var area = res.data.data;
        that.setData({ cinema: area })
       

      }
    })
  }
})