//index.js
//获取应用实例
var app = getApp()
Page({
  data: {

  },
  //进来页面获取订单主键
  onLoad: function (e) {
    console.info("onLoad=====")
    console.info(e)
    this.data.order_id = e.id;
    //临时数据
    //this.data.order_id = ;
  },

  //评论事件处理函数
  formSubmit: function (e) {

    console.log('form发生了submit事件，携带数据为：', e.detail.value)
    //组装参数和值    
    let param = e.detail.value;
    param.id = this.data.order_id;
    param.a_img = app.globalData.userInfo.avatarUrl;
    console.info("=======----")
    console.info(param)

    //获取登录的token

    //发送网络请求，获取数据
    var that = this
    wx.request({
      url: app.globalData.backend_url + '/question/add',
      data: param,
      method: 'POST',
      success: function (res) {
        console.info(res)

        //评论成功提示
        if (res.data.errno == 0) {
          wx.showToast({
            title: '回答成功',
            icon: 'success',
            duration: 2000
          })
        } else {
          //评论失败提示
          wx.showToast({
            title: '回答失败',
            icon: 'loading',
            duration: 1000
          })

        };

      }



    })

  }

});