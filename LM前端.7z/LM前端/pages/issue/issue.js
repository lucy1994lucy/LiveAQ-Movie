//index.js
//获取应用实例
var app = getApp()


Page({
  data: {
    req: [{
      "action": 'zan',
      "hashId": '1',
      "zan": 1
    }]

  },
  onLoad: function (ev) {
    console.log(ev)

    var that = this
    console.log('onLoad')
    wx.request({
      url: app.globalData.backend_url + '/question/find?id=' + ev.id,
      header: {
        'Content-Type': 'application/json'
      },
      success: function (res) {
        that.setData({
          obj: res.data.data
        })

      }
    })
  },
  
  onShareAppMessage: function () {
    return {
      "title": "极客分答",
      "desc": "这里是极客分答",
      "path": "/pages/index/index"
    }
  },
  // 赞
  zan: function (e) {
    let id = e.target.dataset.id;
    this.setFava(id, 'zan');
  },
  setFava: function (id, type) {
    let list = this.data.req;
    for (let i = 0; i < list.length; i++) {
      // 对应数据
      if (list[i].hashId == id) {
        if (list[i].action === type) {
          // 之前相同操作
          list[i][type] > 0 ? list[i][type]-- : null;
          list[i].action = '';
        } else if (list[i].action && list[i].action !== type) {
          // 之前相反操作
          list[i][type === 'cai' ? 'zan' : 'cai']--;
          list[i].action = type;
          list[i][type]++;
        } else {
          // 之前没有操作
          list[i].action = type;
          list[i][type]++;
        }
        this.setData({ req: list });
        break;
      }
    }
  },
 
})
